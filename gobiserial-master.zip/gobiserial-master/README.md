# GobiSerial for Qualcomm 3000 modems patched for new Linux kernels

This project aims to introduce support to the GobiSerial module (needed to
use Gobi 3000 broadband modems) for the newer Linux kernels.

This project hosts a patched version of GobiSerial kernel module. 

# Documentation

As for now, please refer to the [project wiki](https://github.com/casastorta/gobiserial/wiki)
for details on install, contributing and usage.
